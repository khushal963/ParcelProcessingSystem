//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

public class Parcel {
    String id;
    int weight;
    int daysInDepot;
    boolean isCollected;

    public Parcel(String id, int weight, int daysInDepot) {
        this.id = id;
        this.weight = weight;
        this.daysInDepot = daysInDepot;
        this.isCollected = false;
    }
}
